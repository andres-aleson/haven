---
name: Serene Pulse
colors:
  surface: '#f8faf8'
  surface-dim: '#d8dad9'
  surface-bright: '#f8faf8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f2'
  surface-container: '#eceeec'
  surface-container-high: '#e6e9e7'
  surface-container-highest: '#e1e3e1'
  on-surface: '#191c1b'
  on-surface-variant: '#434841'
  inverse-surface: '#2e3130'
  inverse-on-surface: '#eff1ef'
  outline: '#737970'
  outline-variant: '#c3c8bf'
  surface-tint: '#4a6549'
  primary: '#4a6549'
  on-primary: '#ffffff'
  primary-container: '#8ba888'
  on-primary-container: '#243d24'
  inverse-primary: '#b0cfad'
  secondary: '#4858ab'
  on-secondary: '#ffffff'
  secondary-container: '#96a5ff'
  on-secondary-container: '#27378a'
  tertiary: '#645e4b'
  on-tertiary: '#ffffff'
  tertiary-container: '#a8a08a'
  on-tertiary-container: '#3c3726'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ccebc7'
  primary-fixed-dim: '#b0cfad'
  on-primary-fixed: '#07200b'
  on-primary-fixed-variant: '#334d33'
  secondary-fixed: '#dee0ff'
  secondary-fixed-dim: '#bac3ff'
  on-secondary-fixed: '#00105b'
  on-secondary-fixed-variant: '#2f3f92'
  tertiary-fixed: '#ece2c9'
  tertiary-fixed-dim: '#cfc6ae'
  on-tertiary-fixed: '#201b0c'
  on-tertiary-fixed-variant: '#4c4634'
  background: '#f8faf8'
  on-background: '#191c1b'
  surface-variant: '#e1e3e1'
typography:
  headline-lg:
    fontFamily: Quicksand
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Quicksand
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Quicksand
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-margin: 24px
  gutter: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
  stack-xl: 48px
---

## Brand & Style

The design system is centered on "Gentle Support." It aims to bridge the gap between a sterile medical tool and a chaotic social media platform, creating a "third space" that feels safe, private, and non-judgmental for teenagers. 

The style utilizes a **Modern Minimalist** foundation infused with **Soft Tactility**. It prioritizes extreme clarity and breathing room to reduce cognitive load for users who may be experiencing anxiety or distress. Every interaction should feel intentional and calm, avoiding aggressive animations or high-pressure UI patterns. The aesthetic is welcoming and organic, using soft edges and natural tones to evoke a sense of grounding and stability.

## Colors

The palette is rooted in nature and tranquility. We avoid pure #000000 black and pure #FFFFFF white to reduce eye strain and clinical coldness.

- **Primary (Sage):** Used for main actions, active states, and reassurance. It symbolizes growth and peace.
- **Secondary (Muted Indigo):** Used for focus areas and secondary interactive elements.
- **Surface & Background:** We use a very light tinted sage (#F9FBF9) for the global background to create a "paper-like" warmth.
- **Mood Accents:** Specific hex codes are reserved for functional categories:
    - **Breathing:** Soft Dusty Blue (#9DBAD5)
    - **Journaling:** Pale Lavender (#BEB4D6)
    - **Grounding:** Earthy Tan (#D9C5B2)
- **Typography:** Deep charcoal (#2D3436) provides high legibility without the harshness of true black.

## Typography

This design system uses a dual-font approach to balance friendliness with functional clarity.

- **Quicksand (Headlines):** Its rounded terminals and open apertures provide a soft, welcoming "voice." It is used for all major headings and encouraging prompts.
- **Inter (Body & Labels):** Chosen for its exceptional readability at small sizes and its neutral, trustworthy character. It handles the "heavy lifting" of settings, journal entries, and instructional text.

**Hierarchy Rules:**
- Use `headline-lg` for daily check-ins and welcoming messages.
- Maintain generous line-heights (1.5x for body text) to ensure content never feels cramped or overwhelming.

## Layout & Spacing

The layout philosophy is **Generous and Fluid**. We prioritize vertical rhythm to prevent the UI from feeling cluttered.

- **Grid:** A 12-column grid for desktop/tablet and a 4-column grid for mobile.
- **Margins:** 24px horizontal margins on mobile to ensure content doesn't feel "trapped" against the screen edges.
- **Visual Weight:** Group related elements using `stack-md`. Create distinct sections using `stack-xl`.
- **White Space:** Do not fear empty space. Large gaps between sections are encouraged to allow the user to focus on one thought at a time.

## Elevation & Depth

To maintain a "non-clinical" and soft feel, the design system avoids heavy, dark shadows.

- **Tonal Layers:** Depth is primarily communicated through subtle shifts in background color (e.g., a white card on a soft sage background).
- **Ambient Shadows:** When elevation is required (for buttons or floating action cards), use "Soft Glow" shadows. These are very large radius, low opacity (4-8%) shadows tinted with the Primary Sage color rather than gray.
- **Inner Depth:** For input fields and progress tracks, use a subtle 1px inner border rather than a drop shadow to create a "pressed" or "contained" feel.

## Shapes

The shape language is defined by extreme softness. Sharp corners are strictly avoided as they can appear aggressive or institutional.

- **Base Radius:** 16px (`rounded-md`).
- **Large Components:** Cards and main containers use 24px (`rounded-xl`).
- **Interactive Elements:** Buttons and tags utilize a full "pill" shape (999px) where possible to invite touch and feel approachable.

## Components

### Buttons
- **Primary:** Pill-shaped, Primary Sage background, white text. No harsh borders.
- **Secondary:** Transparent background with a 2px Sage border.
- **Tertiary/Ghost:** Text-only with an underline or icon for navigational links.

### Cards
- Always use a white background with a `rounded-xl` (24px) corner radius.
- Borders should be 1.5px thick using a very light tint of the Primary color (e.g., #E8EEE8) instead of gray.

### Input Fields
- Use a soft off-white fill. On focus, the border transitions to Primary Sage with a soft outer glow. 
- Labels always sit above the field in `label-md` for maximum clarity.

### Chips & Tags
- Used for mood selection. Use high-contrast pill shapes.
- When selected, a chip should "glow" slightly with its specific category color (e.g., a "Calm" chip glows soft blue).

### Progress Indicators
- Thick, rounded tracks (8px height). Use the accent colors to show progress through breathing or grounding exercises. Avoid "Success Green" vs "Error Red" metaphors; use Sage for all positive progression.

### Navigation
- A bottom navigation bar with large, simple icons and clear labels. The active state is indicated by a soft sage circular background behind the icon.